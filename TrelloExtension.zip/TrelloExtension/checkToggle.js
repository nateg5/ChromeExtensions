checkboxes = document.getElementsByClassName('checklist-item-checkbox-check');
for(let i = 0; i < checkboxes.length; i++) {
    setTimeout(function() {
        checkboxes[i].click();
    }, (i * 1000));
}