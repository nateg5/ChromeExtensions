items = document.getElementsByClassName('zg-item-immersion');
itemsArray = [];
for(let i = 0; i < items.length; i++) {
	let rating = items[i].getElementsByClassName('a-icon-alt');
	rating = rating[0].innerHTML.substring(0, 3);
	rating = parseFloat(rating);
	let count = items[i].getElementsByClassName('a-size-small a-link-normal');
	count = count[0].innerHTML;
	count = parseInt(count);
	itemsArray.push({
		item: items[i],
		rating: (rating * count) / (count + 1)
	});
}
itemsArray.sort(function(a, b) {
	return b.rating - a.rating;
});
for(let i = 0; i < itemsArray.length; i++) {
	if(i < 5) {
        itemsArray[i].item.style.backgroundColor = '#ffff80';
	} else {
		itemsArray[i].item.style.display = 'none';
	}
}