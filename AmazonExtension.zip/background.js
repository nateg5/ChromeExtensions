"use strict";

/*chrome.runtime.onInstalled.addListener(function () {
  chrome.action.disable();
});*/
